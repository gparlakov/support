﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeckLibrary
{
    /// <summary>
    /// Generic implementation of Deque using LinkedList
    /// </summary>
    /// <typeparam name="T">The type used in instance</typeparam>
    public class Deque<T>: IDeque<T>
    {
        private LinkedList<T> deque;

        /// <summary>
        /// Constructs a new instance of the Deque class with given type
        /// </summary>
        public Deque()
        {
            this.deque = new LinkedList<T>();
        }

        /// <summary>
        /// Gets the count of elements in the deque 
        /// </summary>
        /// <returns>Count of elements</returns>
        public int Count()
        {
            return this.deque.Count;
        }

        /// <summary>
        /// Adds an element at the start of the queue
        /// </summary>
        /// <param name="element">The element to add</param>
        public void PushFirst(T element)
        {
            this.deque.AddFirst(element);
        }

        /// <summary>
        /// Adds an element at the end of the queue
        /// </summary>
        /// <param name="element">The element to add</param>
        public void PushLast(T element)
        {
            this.deque.AddLast(element);
        }

        /// <summary>
        /// Gets the value of the first element and removes it from the queue
        /// </summary>
        /// <returns>The first element</returns>
        public T PopFirst()
        {
            var first = this.deque.First;
            this.deque.RemoveFirst();

            return first.Value;
        }

        /// <summary>
        /// Gets the value of the last element and removes it from the queue
        /// </summary>
        /// <returns>The last element</returns>
        public T PopLast()
        {
            var last = this.deque.Last;
            this.deque.RemoveLast();

            return last.Value;
        }

        /// <summary>
        /// Gets the value of the first element
        /// </summary>
        /// <returns>The first element</returns>
        public T PeekFirst()
        {
            return this.deque.First.Value;
        }

        /// <summary>
        /// Gets the value of the last element
        /// </summary>
        /// <returns>The last element</returns>
        public T PeekLast()
        {
            return this.deque.Last.Value;
        }

        /// <summary>
        /// Clears all elements from the queue
        /// </summary>
        public void Clear()
        {
            this.deque.Clear();
        }

        /// <summary>
        /// Checks if a given instance is inside the queue
        /// </summary>
        /// <param name="element">The element to search for</param>
        /// <returns>True if the element is inside the queue, otherwise - false</returns>
        public bool Contains(T element)
        {
            return this.deque.Contains(element);
        }
    }

    /// <summary>
    /// The interface to implement when creating Deque
    /// </summary>
    /// <typeparam name="T">The type to use in instances of the implementantion</typeparam>
    public interface IDeque<T>
    {
        int Count();
        void PushFirst(T element);
        void PushLast(T element);
        T PopFirst();
        T PopLast();              
        T PeekFirst();
        T PeekLast();
        void Clear();              
        bool Contains(T element);
    }
}
